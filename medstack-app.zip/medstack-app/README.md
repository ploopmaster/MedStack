# MedStack (real Google login + shared temporary storage)

Node/Express backend that verifies Google sign-ins server-side and stores posts/files on disk, shared by everyone you invite.

## 1. Create the Google OAuth Client ID (free, ~5 minutes)
1. Go to https://console.cloud.google.com and create/select a project.
2. **APIs & Services > OAuth consent screen**: choose *External*, fill in app name (MedStack) and your email. Under **Test users**, add your Gmail and your friend's Gmail.
3. **APIs & Services > Credentials > Create credentials > OAuth client ID** > type **Web application**.
4. **Authorized JavaScript origins**: add `http://localhost:3000` and, once deployed, your live URL (e.g. `https://medstack.onrender.com`). No redirect URI is needed.
5. Copy the **Client ID** (ends in `.apps.googleusercontent.com`).

## 2. Run locally
```
npm install
cp .env.example .env      # then edit: GOOGLE_CLIENT_ID, SESSION_SECRET, ALLOWED_EMAILS
npm run dev               # needs Node 20+
```
Open http://localhost:3000

## 3. Deploy so your friend can use it (example: Render.com)
- Push this folder to GitHub > Render > New Web Service. Build: `npm install`, Start: `npm start`.
- Add the .env values as Environment Variables plus `NODE_ENV=production`.
- Add the Render URL to *Authorized JavaScript origins* in Google Cloud.
- Share the URL. Add your friend's email to `ALLOWED_EMAILS`.

## Custom domain: www.medstack.edu.pk
1. `.edu.pk` domains are only issued by PKNIC to recognised Pakistani educational institutions. Apply through your institution. If you can't get one, use `medstack.pk`, `medstack.com.pk` or `medstack.com` and change the values below.
2. In your host (e.g. Render > Settings > Custom Domains) add **both** `www.medstack.edu.pk` and `medstack.edu.pk`. The host shows the DNS records to create.
3. At your registrar/DNS: add a `CNAME` for `www` pointing to your host's address, and the record your host gives for the bare domain (an `A`/`ALIAS` record). HTTPS is issued automatically once DNS resolves (can take up to a few hours).
4. Set env vars `CANONICAL_HOST=www.medstack.edu.pk` and `NODE_ENV=production`. The server then redirects `http://` and the bare domain to `https://www.medstack.edu.pk`.
5. Google Cloud Console > Credentials > your OAuth client > **Authorized JavaScript origins**: add `https://www.medstack.edu.pk`. Login will not work on the new address until you do.

## Temporary storage
Files live in `DATA_DIR/uploads` and are auto-deleted after `TTL_HOURS` (default 24; set 0 to keep). On free hosts the disk also resets on redeploy/sleep, which suits temporary use. For permanent storage, attach a persistent disk or swap in S3/Cloud Storage.

## Security notes
Google ID tokens are verified on the server; sessions are httpOnly cookies; only the uploader can delete a post; 25 MB per file; risky file types are always served as downloads, never rendered. Don't upload real patient-identifiable data to a hobby deployment.
