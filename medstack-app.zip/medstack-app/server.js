const express = require('express'), multer = require('multer'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const cookieParser = require('cookie-parser'), jwt = require('jsonwebtoken');
const { OAuth2Client } = require('google-auth-library');

const { GOOGLE_CLIENT_ID, SESSION_SECRET, ALLOWED_EMAILS = '', TTL_HOURS = '24', PORT = 3000, DATA_DIR = './data', CANONICAL_HOST = '' } = process.env;
if (!GOOGLE_CLIENT_ID || !SESSION_SECRET) { console.error('Set GOOGLE_CLIENT_ID and SESSION_SECRET (see .env.example)'); process.exit(1); }

const allow = ALLOWED_EMAILS.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
const gc = new OAuth2Client(GOOGLE_CLIENT_ID);
const UP = path.join(DATA_DIR, 'uploads'), DB = path.join(DATA_DIR, 'posts.json');
fs.mkdirSync(UP, { recursive: true });
let posts = fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, 'utf8')) : [];
const save = () => fs.writeFileSync(DB, JSON.stringify(posts));

// Temporary storage: delete anything older than TTL_HOURS
const ttl = Number(TTL_HOURS) * 3600e3;
function sweep() {
  if (!ttl) return;
  const now = Date.now();
  posts = posts.filter(p => now - p.date < ttl || (fs.rm(path.join(UP, p.id), { force: true }, () => {}), false));
  save();
}
setInterval(sweep, 10 * 60e3); sweep();

const app = express();
app.set('trust proxy', 1);
// Send http -> https and bare domain -> www (e.g. medstack.edu.pk -> www.medstack.edu.pk)
app.use((req, res, next) => {
  if (process.env.NODE_ENV !== 'production' || !CANONICAL_HOST) return next();
  const bare = CANONICAL_HOST.replace(/^www\./, '');
  if (req.hostname === bare || req.protocol !== 'https' && req.hostname === CANONICAL_HOST)
    return res.redirect(301, `https://${CANONICAL_HOST}${req.originalUrl}`);
  next();
});
app.use(express.json(), cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const cookieOpts = { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 864e5 };
function auth(req, res, next) {
  try { req.user = jwt.verify(req.cookies.ms, SESSION_SECRET); next(); }
  catch { res.status(401).json({ error: 'Please sign in' }); }
}

app.get('/api/config', (req, res) => res.json({ clientId: GOOGLE_CLIENT_ID, ttlHours: Number(TTL_HOURS) }));

// Verify the Google ID token on the server, then start our own session
app.post('/api/login', async (req, res) => {
  try {
    const ticket = await gc.verifyIdToken({ idToken: req.body.credential, audience: GOOGLE_CLIENT_ID });
    const p = ticket.getPayload();
    if (!p.email_verified) return res.status(403).json({ error: 'Google email not verified' });
    if (allow.length && !allow.includes(p.email.toLowerCase())) return res.status(403).json({ error: 'This email is not on the invite list' });
    const user = { sub: p.sub, name: p.name, email: p.email, picture: p.picture };
    res.cookie('ms', jwt.sign(user, SESSION_SECRET, { expiresIn: '7d' }), cookieOpts).json(user);
  } catch { res.status(401).json({ error: 'Invalid Google sign-in' }); }
});
app.get('/api/me', auth, (req, res) => res.json(req.user));
app.post('/api/logout', (req, res) => res.clearCookie('ms').json({ ok: true }));

const upload = multer({
  storage: multer.diskStorage({ destination: UP, filename: (r, f, cb) => cb(null, crypto.randomBytes(16).toString('hex')) }),
  limits: { fileSize: 25 * 1024 * 1024, files: 10 }
});

const pub = ({ id, title, desc, cat, name, type, size, author, date, owner }, me) => ({ id, title, desc, cat, name, type, size, author, date, mine: owner === me });

app.get('/api/posts', auth, (req, res) => res.json(posts.slice().sort((a, b) => b.date - a.date).map(p => pub(p, req.user.sub))));

app.post('/api/posts', auth, upload.array('files', 10), (req, res) => {
  const cats = ['Anatomy', 'Cardiology', 'Pharmacology', 'Radiology', 'Lab Results', 'Case Report', 'Other'];
  for (const f of req.files || []) {
    posts.push({
      id: f.filename, title: String(req.body.title || f.originalname).slice(0, 120), desc: String(req.body.desc || '').slice(0, 500),
      cat: cats.includes(req.body.cat) ? req.body.cat : 'Other', name: f.originalname.slice(0, 200), type: f.mimetype, size: f.size,
      author: req.user.name, owner: req.user.sub, date: Date.now()
    });
  }
  save(); res.json({ ok: true });
});

const INLINE = /^(image\/(png|jpeg|gif|webp)|application\/pdf)$/;
app.get('/api/files/:id', auth, (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.sendStatus(404);
  const inline = req.query.download !== '1' && INLINE.test(p.type);
  res.set({ 'Content-Type': inline ? p.type : 'application/octet-stream', 'X-Content-Type-Options': 'nosniff',
    'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(p.name)}` });
  res.sendFile(path.resolve(UP, p.id));
});

app.delete('/api/posts/:id', auth, (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.sendStatus(404);
  if (p.owner !== req.user.sub) return res.status(403).json({ error: 'You can only delete your own posts' });
  posts = posts.filter(x => x !== p); save();
  fs.rm(path.join(UP, p.id), { force: true }, () => {});
  res.json({ ok: true });
});

app.use((err, req, res, next) => res.status(400).json({ error: err.message || 'Upload failed' }));
app.listen(PORT, () => console.log(`MedStack running on http://localhost:${PORT}`));
